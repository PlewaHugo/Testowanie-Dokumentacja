/**
 * Funkcja dzieli 2 liczby
 * @param {number} a - Licznik
 * @param {number} b - Mianownik
 * @throws {Error} gdy b będzie zerem
 * @returns {number} wynik dzielenia 
 * @example 
 * const a = 10
 * const b = 2
 * const result = divide(a,b)
 * console.log(result)//result = 5
 * 
 * 
 * @author Hugo Plewa 5D
 */



function divide(a, b){
    if(b==0){
        throw new Error("Nie dziel holero przez zero")
    }
    return a/b
}