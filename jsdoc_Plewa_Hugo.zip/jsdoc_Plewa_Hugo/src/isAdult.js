/**
 * Funkcja sprawdza czy użytkownik jest dorosły
 * @param {number} age wiek użytkownika 
 * @returns {boolean} zwraca false jeżeli jesteś niepełnoletni, a true jeżeli pełnoletni
 * @throws {Error} jeżeli wiek jest mniejszy lub równy 0
 * 
 * 
 * @author Hugo Plewa 5D
 */
function isAdult(age){
    if(age<=0){
        throw new Error("Co ty gościu masz ujemny wiek?")
        
    }
    if(age>18){
        return true
    }
    else{
        return false
    }
}