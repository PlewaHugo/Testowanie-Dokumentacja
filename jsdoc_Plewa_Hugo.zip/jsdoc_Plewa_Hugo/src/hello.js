/**
 * Pokazuje alert Hello (imie użytkownika)
 * @param {string} somebody imie użytkownika
 * @returns {undefined} nic nie zwraca
 * 
 * 
 * @author Hugo Plewa 5D
 */
const sayHello = (somebody) => {
    alert(`Hello ${somebody}`);
}