/**
 * funkcja liczy pole okręgu
 * @param {number} radius promień okręgu 
 * @returns {number} pole okręgu
 * @throws {Error} gdy promień mniejszy lub równy 0
 * 
 * 
 * @author Hugo Plewa 5D
 */



function calculateArea(radius){
    if(r<=0){
        throw new Error("Promień powinien być większy od 0")
    }
    return Math.PI*r*r
}